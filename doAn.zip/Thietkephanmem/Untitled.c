#include<P18F4520.h>
#include<adc.h>
#include<delays.h>
#include<stdio.h>
#pragma config OSC = HS //ch? d? dao d?ng HS
#pragma config MCLRE = ON //s? d?ng RE3 l�m ch�n reset (OFF: kh�ng s? d?ng)
#pragma config WDT = OFF //kh�ng d�ng Watchdog timer
#pragma config PBADEN = OFF //PORTB<4:0> du?c c?u h�nh th�nh c�c ch�n v�o/ra s?
//ON: PORTB<4:0> du?c c?u h�nh th�nh c�c ch�n AN8-AN12
#pragma config PWRT=ON // s? d?ng Power-up timer
#pragma config BOREN=OFF // kh�ng s? d?ng ch?c nang Bown-out reset
//(reset khi Vdd xu?ng th?p du?i 1 ngu?ng)
#pragma config LVP=OFF //kh�ng d?ng ch? d? c?p ngu?n ch? t? m?ch n?p	
#define ldata  PORTD
#define RS_lcd PORTEbits.RE0
#define RW_lcd PORTEbits.RE1
#define EN_lcd PORTEbits.RE2
#define bom PORTCbits.RC0
#define D1 PORTCbits.RC1
#define D2 PORTCbits.RC2
#define D4 PORTCbits.RC3
char temp[]="NHIET DO : ", soil[]="DO AM DAT: ", on[]="ON", off[]="OFF", group[]="NHOM 06", member[]="HUY-HIEU";
unsigned int n, m;		
int mode=0; 
void Lcd_Init(void);							
void write_command(unsigned char lcd_command);	
void write_data(unsigned char lcd_data);		
void write_string(char *s);						
void cambien(void);
void chedo1(void);
void chedo2(void);
void delay_timer0(unsigned int t);
void ngat_ngoai(void);

#pragma code uu_tien_cao = 0x08 
void ngat_cao(void)
{
	ngat_ngoai(); 
}

#pragma code
#pragma interrupt ngat_ngoai
void ngat_ngoai(void)
{
		mode++;
		if(mode==3) mode=1;
		INTCON3bits.INT1IF=0; 
}                                   
void main(void)
{	
	TRISA = 0xFF;  								
	TRISE = 0x00;  							
	TRISD = 0x00;  							
	TRISC = 0x00;								
	TRISB = 0x0f;
	PORTC = 0x00;							
	ADCON1 = 0X0D;		
						
	INTCONbits.GIE=1;
	INTCONbits.PEIE=0; 
	INTCON3bits.INT1IE=1;
	INTCON2bits.INTEDG1=0;
	
	T0CONbits.TMR0ON=1;
	T0CONbits.T08BIT=0;
    T0CONbits.T0CS=0;
	T0CONbits.T0SE=1;
	T0CONbits.PSA=0; 
	T0CONbits.T0PS2=1;
	T0CONbits.T0PS1=0;
	T0CONbits.T0PS0=0;
	
	OpenADC(			ADC_FOSC_32 &					
		      			ADC_RIGHT_JUST &				
		    			ADC_12_TAD,						
		    			ADC_CH0 &						
		    			ADC_INT_OFF& 				    
		    			ADC_VREFPLUS_VDD & 				
		    			ADC_VREFMINUS_VSS,				
						0b00001101);					
	Lcd_Init();	
	write_command(0x01);						
	while(1)
	{	
		if(mode==0)
		{
			write_command(0x01);					
			write_command(0X83);
			sprintf(&group[0],"NHOM 06");
	    	write_string(&group[0]);					
			write_command(0XC3);
			sprintf(&member[0],"HUY-HIEU");
	    	write_string(&member[0]);					
			delay_timer0(2);
		}	
		if(mode==1)
			chedo1();
		if(mode==2)
			chedo2();		
	}
}
void Lcd_Init(void)
{
	write_command(0x03); 
	write_command(0x38); 
	write_command(0x06); 
	write_command(0x0c); 
}
void write_command(unsigned char lcd_command) 
{
	RS_lcd=0; 
	RW_lcd=0;
	EN_lcd=1;
	ldata=lcd_command;
	EN_lcd=0;
	Delay10KTCYx(2);	
}
void write_data(unsigned char lcd_data) 
{
	RS_lcd=1;  
	RW_lcd=0;
	EN_lcd=1;
	ldata=lcd_data;
	EN_lcd=0;
	Delay10KTCYx(2);
}
void write_string(char *s)	
{
	while(*s)
	{
		write_data(*s);
		s++;
	}
}
void cambien(void)
{
	if(mode==2) 
		Delay10KTCYx(1);
	else
	{
							
		SetChanADC(ADC_CH0);					
		ConvertADC(); 						
		while(BusyADC());					
		n = ReadADC(); 						
		SetChanADC(ADC_CH1);
		
		ConvertADC(); 						
		while(BusyADC());					
		m = ReadADC(); 						
		m = 1000 - m/1.024f;
		write_command(0X80);
		sprintf(&soil[0],"DO AM DAT: %d%d.%d%",m/100,m%100/10,m%10);
	    write_string(&soil[0]);					
		
		n = (n*100.0*5.0)/1024.0;
		write_command(0XC0);
		sprintf(&temp[0],"NHIET DO : %d%d%d",n/100,n%100/10,n%10);				
	    write_string(&temp[0]);
	    write_data(0xDF);					
		write_data('C');					
		Delay10KTCYx(600);					
	}
}   
void chedo1(void)
{
	D1=1;D2=0;
	cambien();		 
	if(m<400)
	{
		bom=1;
		D4=0;
	}
	else if(m>600) 
	{
		D4=0;
		bom=0;
	}
	else if(m<500||m>700) 
		D4=0;
	else if(500<=m<=700)
		D4=1;
}
void chedo2(void)
{
	D2=1;D1=1;D4=0;
	if(mode==1) 
		Delay10KTCYx(1);
	else
	{
		write_command(0x01);				
		write_command(0X86);
		sprintf(&on[0],"ON");				
	   	write_string(&on[0]);					
		bom = 1;
		delay_timer0(2);
	}
	if(mode==1) 
		Delay10KTCYx(1);	
	else	
	{
		write_command(0x01);				
		write_command(0X86);
	   	sprintf(&off[0],"OFF");				
	   	write_string(&off[0]);					
		bom = 0;
		delay_timer0(4);	
 	}			
}	
void delay_timer0(unsigned int t)			
{
	while(t--)
	{
		if(mode==1) break;
		TMR0H=(65536-62500)/256;
		TMR0L=(65536-62500)%256;
		while(INTCONbits.TMR0IF==0);
		INTCONbits.TMR0IF=0;
	}
}                  
